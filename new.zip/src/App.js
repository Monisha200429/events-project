/*import logo from './logo.svg';
import './App.css';
import { Container, Carousel } from 'react-dom';

function App() {
  return (
    <div className="App">
     <Container />
     <Carousel />
    </div>
  );
}

export default App;*/
// import MovieList from "./components/MovieList";
// import Nav from "./components/nav";
import "./App.css";
import React from "react";
import Post from "./post";
import "./post.css";
// import AddMovie from "./components/AddMovie";
// import { MovieProvider } from "./components/MovieContext";
// import LoginForm from "./components/login";
import Carousel from "./carousel";
import Nav from  "./nav";
function App() {
  return (
      <div>
        <Nav />
        <Carousel /> 
        <Post />
      </div>
  );
}

export default App;
   